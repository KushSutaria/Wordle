import json
import boto3
import hashlib
import os

def lambda_handler(event, context):
    dynamodb_resource=boto3.resource('dynamodb')
    email=event['email']
    password=event['password']
    hashed_password=hashlib.md5(password.encode('utf-8')).hexdigest()
    print(hashed_password)
    
    table=dynamodb_resource.Table(os.environ['TABLE_NAME'])
    response=table.get_item(
        Key={
            'email':email
        })
    if 'Item' in response:
        return 'email exists'
    table.put_item(
        Item={
        'email':email,
        'password':hashed_password,
        'Guess1':0,
        'Guess2':0,
        'Guess3':0,
        'Guess4':0,
        'Guess5':0,
        'Guess6':0,
        }
        )
    # TODO implement
    return {
        'statusCode': 200,
        'body': 'Account Created'
    }
