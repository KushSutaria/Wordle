import boto3
import os
import json

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    table_name = os.environ['TABLE_NAME']
    field_to_update = 'solvedCurrent'
    new_value = False
    print(event)
    # Get the DynamoDB table
    table = dynamodb.Table(table_name)

    # Perform a scan operation to retrieve all items in the table
    response = table.scan()

    # Iterate through the items and update the specified field
    for item in response['Items']:
        item_id = item['email'] 
        # Update the field for the current item
        table.update_item(
            Key={
                'email': item_id
            },
            UpdateExpression=f'SET {field_to_update} = :val',
            ExpressionAttributeValues={
                ':val': new_value
            }
        )

    # Optionally, you can log the completion or any relevant information
    print(f"Field '{field_to_update}' updated to '{new_value}' for all items.")
    

    MessageBody=(event['Records'][0]['body'])
    #print(MessageBody)
    word=(json.loads(MessageBody))['Message']
    print(word)
    if(word!=''):
        #print(word)

        word_table=dynamodb.Table(os.environ['WORD_TABLE_NAME'])
        res=word_table.scan()
        print(res)
        item_count = res['Count']

        print(item_count)
        word_number=item_count+1
        print(word_number)

        word_table.put_item(
            Item={
            'Word':word,
            'number':word_number
            }
            )
    print(word)
'''
    sqs=boto3.resource('sqs')
    word_queue=sqs.get_queue_by_name(QueueName='NewWordNotificationQueue')

    messages=[]
    while True:
        response = word_queue.receive_messages(MaxNumberOfMessages=10)  
       
        if not response:
            break
        else:
            messages.extend(response)
    word=''

    for i in range(len(messages)):
        message=json.loads(messages[i].body)['Message']
        print(message)
        word=message
        messages[i].delete()


    if(word!=''):
        print(word)
        latest_word=word

        word_table=dynamodb.Table(os.environ['WORD_TABLE_NAME'])
        res=word_table.scan()
        print(res)
        item_count = res['Count']

        print(item_count)
        word_number=item_count+1
        print(word_number)

        word_table.put_item(
            Item={
            'Word':latest_word,
            'number':word_number
            }
            )
    print(word)
'''