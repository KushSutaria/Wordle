import json
import boto3
import hashlib
import os

def lambda_handler(event, context):
    dynamodb_resource = boto3.resource('dynamodb')
    email = event['email']
    password = event['password']
    hashed_password = hashlib.md5(password.encode('utf-8')).hexdigest()

    table = dynamodb_resource.Table(os.environ['TABLE_NAME'])
    response = table.get_item(
        Key={
            'email': email
            }
    )

    if 'Item' in response:
        item = response['Item']
        print(item)
        if hashed_password==item['password']:
            print('Logged in!')
            return {
                'statusCode': 200,
                'body': 'Logged in!'
            }
        else:
            return {
                'statusCode': 200,
                'body': 'Invalid Password!'
            }
    else:
            return {
                'statusCode': 200,
                'body': 'Email doesn\'t exist!'
            }

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
