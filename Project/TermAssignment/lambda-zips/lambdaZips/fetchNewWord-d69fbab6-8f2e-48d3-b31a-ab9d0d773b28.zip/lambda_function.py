import json
import boto3
import hashlib
import os

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    word_table=dynamodb.Table(os.environ['WORD_TABLE_NAME'])
    res=word_table.scan()
    item_count = res['Count']

   
    response = word_table.get_item(
        Key={
            'number': item_count
            }
    )

    if 'Item' in response:
        item = response['Item']
        print(item)
        return item
        
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
