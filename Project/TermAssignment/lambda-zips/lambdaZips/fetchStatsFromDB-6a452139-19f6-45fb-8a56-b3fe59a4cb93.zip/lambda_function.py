import json
import boto3
import hashlib
import os

def lambda_handler(event, context):
    dynamodb_resource = boto3.resource('dynamodb')
    email = event['email']

    table = dynamodb_resource.Table(os.environ['TABLE_NAME'])
    response = table.get_item(
        Key={
            'email': email
            }
    )

    if 'Item' in response:
        body={}
        item = response['Item']
        print(item)
        for i in item:
            if i!='password' and i!='email':
                body[i]=item[i]
        print(body)
        return{
            'body':body
        }
    else:
            return {
                'body': 'Something went wrong'
            }

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
