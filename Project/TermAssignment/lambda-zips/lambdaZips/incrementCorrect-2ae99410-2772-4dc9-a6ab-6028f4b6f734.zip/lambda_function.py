import boto3
import os
import json

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    table_name = os.environ['TABLE_NAME']  
    primary_key_value = event['email']  
    attribute_to_increment = event['guess']
    attribute_to_update = 'solvedCurrent' 

    # Get the DynamoDB table
    table = dynamodb.Table(table_name)

    response = table.update_item(
        Key={
            'email': primary_key_value
        },
        UpdateExpression='SET #attr = #attr + :val, #attr2 = :new_val',
        ExpressionAttributeNames={
            '#attr': attribute_to_increment,
            '#attr2': attribute_to_update

        },
        ExpressionAttributeValues={
            ':val': 1,
            ':new_val': True

        },
        
        ReturnValues='UPDATED_NEW'
    )

    # Optionally, you can check the updated value
    updated_count = response['Attributes'][attribute_to_increment]
    print(f"Updated {attribute_to_increment}: {updated_count}")
    return {
        'statusCode': 200,
        'body': 'Updated'
    }
